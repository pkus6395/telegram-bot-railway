
# Deploy Bot Telegram บน Railway

1. สมัครที่ https://railway.app/
2. New Project -> Upload project
3. อัปโหลดไฟล์ bot.py และ requirements.txt
4. ตั้ง Environment Variables:
   - BOT_TOKEN = (Token บอทของคุณ)
5. ตั้ง Start Command เป็น:
   python bot.py
6. กด Deploy ✅
7. เสร็จ! Bot ทำงานได้ ยิงข้อความตามเวลาได้!
